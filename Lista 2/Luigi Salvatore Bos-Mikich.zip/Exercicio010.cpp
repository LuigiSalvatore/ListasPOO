// Nome Arquivo: Exercicio010.cpp
// Nome autor: Luigi Salvatore Bos-Mikich
// Finalidade do Programa:
// Versão: 1.0
// data:

#include <iostream>

using namespace std;

int main(void)
{
}